import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

public class BallPanel extends JPanel {
	
	private Ball ball;
	
	public BallPanel(Dimension initialSize) {
		super();
		ball = new Ball(initialSize.width/2, initialSize.height/2, Math.min(initialSize.width,initialSize.height)/10);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		setBackground(Color.black);
		ball.draw(g);
	}
	
}
